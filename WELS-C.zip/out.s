# 由 wescc 生成
    .section .rodata
.Lfmt_s:
    .asciz "%s"
    .text
    .globl main
main:
    push %rbp
    mov %rsp, %rbp
    sub $1024, %rsp
    movq $10, %rax
    movq %rax, -8(%rbp)
    movq $20, %rax
    movq %rax, -16(%rbp)
    movq -8(%rbp), %rax
    push %rax
    movq -16(%rbp), %rax
    pop %rcx
    cmp %rcx, %rax
    setl %al
    movzbq %al, %rax
    test %rax, %rax
    jz .L0
    .section .rodata
.Lstr0:
    .byte 10, 0
    .text
    lea .Lstr0(%rip), %rax
    push %rax
    .section .rodata
.Lstr1:
    .byte 97, 32, 230, 175, 148, 32, 98, 32, 229, 176, 143, 0
    .text
    lea .Lstr1(%rip), %rax
    push %rax
    pop %rsi
    lea .Lfmt_s(%rip), %rdi
    movl $0, %eax
    call printf
    pop %rsi
    lea .Lfmt_s(%rip), %rdi
    movl $0, %eax
    call printf
    movq $0, %rax
    jmp .L1
.L0:
    .section .rodata
.Lstr2:
    .byte 10, 0
    .text
    lea .Lstr2(%rip), %rax
    push %rax
    .section .rodata
.Lstr3:
    .byte 97, 32, 230, 175, 148, 32, 98, 32, 229, 164, 167, 0
    .text
    lea .Lstr3(%rip), %rax
    push %rax
    pop %rsi
    lea .Lfmt_s(%rip), %rdi
    movl $0, %eax
    call printf
    pop %rsi
    lea .Lfmt_s(%rip), %rdi
    movl $0, %eax
    call printf
    movq $0, %rax
.L1:
    movq $0, %rax
    leave
    ret
    movq $0, %rax
    leave
    ret
    .section .note.GNU-stack,"",@progbits