#include "parser.h"

typedef struct {
    lexer_t *L;
    token_t  cur;
    token_t  next;
    int      has_next;
} parser_t;

static int parse_expr(parser_t *P, expr_t **out);
static int parse_block(parser_t *P, stmt_t **out);
static int parse_stmt(parser_t *P, stmt_t **out);

static void p_advance(parser_t *P) {
    if (!P->has_next) {
        if (lex_next(P->L, &P->next) < 0) P->next.kind = TOK_EOF;
        P->has_next = 1;
    }
    P->cur = P->next;
    P->has_next = 0;
}

static void p_peek(parser_t *P) {
    if (!P->has_next) {
        if (lex_next(P->L, &P->next) < 0) P->next.kind = TOK_EOF;
        P->has_next = 1;
    }
}

static int p_err(parser_t *P, const char *msg) {
    fprintf(stderr, "%d:%d: 语法错误: %s\n", P->cur.line, P->cur.col, msg);
    return -1;
}

static int is_kw(parser_t *P, int kw) {
    return P->cur.kind == TOK_KEYWORD && P->cur.kw_id == kw;
}

static int is_op(parser_t *P, const char *op) {
    return P->cur.kind == TOK_OP
        && P->cur.len == (int)strlen(op)
        && memcmp(P->cur.start, op, P->cur.len) == 0;
}

static int is_punct(parser_t *P, int c) {
    return P->cur.kind == TOK_PUNCT
        && P->cur.len == 1
        && P->cur.start[0] == c;
}

static int expect_punct(parser_t *P, int c, const char *what) {
    if (!is_punct(P, c)) return p_err(P, what);
    p_advance(P);
    return 0;
}

static int expect_op(parser_t *P, const char *op, const char *what) {
    if (!is_op(P, op)) return p_err(P, what);
    p_advance(P);
    return 0;
}

static expr_t *new_expr(expr_kind_t k) {
    expr_t *e = calloc(1, sizeof(*e));
    if (!e) { fprintf(stderr, "out of memory\n"); exit(1); }
    e->kind = k;
    return e;
}

static stmt_t *new_stmt(stmt_kind_t k) {
    stmt_t *s = calloc(1, sizeof(*s));
    if (!s) { fprintf(stderr, "out of memory\n"); exit(1); }
    s->kind = k;
    return s;
}

static void add_stmt(stmt_t *blk, stmt_t *s) {
    blk->stmts = realloc(blk->stmts, sizeof(stmt_t *) * (blk->nstmts + 1));
    blk->stmts[blk->nstmts++] = s;
}

/* ============ 类型解析 ============ */

/* 读到一串关键字/标识符，遇到修饰符或终止符停止 */
static int parse_type(parser_t *P, type_desc_t *out) {
    memset(out, 0, sizeof(*out));

    /* 修饰符（前缀） */
    for (;;) {
        if (is_kw(P, KW_CONST))      { out->is_const = 1; p_advance(P); continue; }
        if (is_kw(P, KW_STATIC))     { out->is_static = 1; p_advance(P); continue; }
        if (is_kw(P, KW_LOCAL))      { out->is_local = 1; p_advance(P); continue; }
        if (is_kw(P, KW_GLOBAL))     { p_advance(P); continue; }
        if (is_kw(P, KW_CONTAINER))  { out->is_container = 1; p_advance(P); continue; }
        break;
    }

    /* 基础类型 */
    if (P->cur.kind == TOK_KEYWORD || P->cur.kind == TOK_IDENT) {
        out->base = P->cur.start;
        out->base_len = P->cur.len;
        p_advance(P);
    } else {
        return p_err(P, "期望类型");
    }

    /* 修饰后缀（可叠加） */
    for (;;) {
        if (is_kw(P, KW_PTR))   { out->is_ptr = 1; p_advance(P); continue; }
        if (is_kw(P, KW_REF))   { out->is_ref = 1; p_advance(P); continue; }
        if (is_kw(P, KW_ARRAY)) { out->is_array = 1; p_advance(P); continue; }
        if (is_kw(P, KW_RANGE)) { out->is_range = 1; p_advance(P); continue; }
        break;
    }
    return 0;
}

/* ============ 表达式 ============ */

static int parse_primary(parser_t *P, expr_t **out) {
    p_peek(P);

    if (P->cur.kind == TOK_NUM_INT) {
        expr_t *e = new_expr(EX_INT);
        e->line = P->cur.line; e->col = P->cur.col;
        e->ival = P->cur.ival;
        p_advance(P); *out = e; return 0;
    }
    if (P->cur.kind == TOK_NUM_FLOAT) {
        expr_t *e = new_expr(EX_FLOAT);
        e->line = P->cur.line; e->col = P->cur.col;
        e->fval = P->cur.fval;
        p_advance(P); *out = e; return 0;
    }
    if (P->cur.kind == TOK_STRING) {
        expr_t *e = new_expr(EX_STRING);
        e->line = P->cur.line; e->col = P->cur.col;
        e->name = P->cur.start; e->name_len = P->cur.len;
        p_advance(P); *out = e; return 0;
    }
    if (P->cur.kind == TOK_CHAR) {
        expr_t *e = new_expr(EX_INT);
        e->line = P->cur.line; e->col = P->cur.col;
        e->ival = P->cur.ival;
        p_advance(P); *out = e; return 0;
    }
    if (P->cur.kind == TOK_IDENT) {
        expr_t *e = new_expr(EX_IDENT);
        e->line = P->cur.line; e->col = P->cur.col;
        e->name = P->cur.start; e->name_len = P->cur.len;
        p_advance(P); *out = e; return 0;
    }
    if (is_punct(P, '(')) {
        p_advance(P);
        if (parse_expr(P, out) < 0) return -1;
        return expect_punct(P, ')', "期望 ')'");
    }
    return p_err(P, "期望表达式");
}

static int parse_postfix(parser_t *P, expr_t **out) {
    if (parse_primary(P, out) < 0) return -1;
    p_peek(P);
    if (is_punct(P, '(')) {
        p_advance(P);
        expr_t *call = new_expr(EX_CALL);
        call->line = (*out)->line; call->col = (*out)->col;
        call->operand = *out;

        /* 参数之间逗号可选 */
        while (!is_punct(P, ')') && P->cur.kind != TOK_EOF) {
            expr_t *arg;
            if (parse_expr(P, &arg) < 0) return -1;
            call->args = realloc(call->args, sizeof(expr_t*) * (call->nargs + 1));
            call->args[call->nargs++] = arg;
            p_peek(P);
            if (is_punct(P, ',')) p_advance(P);
        }
        if (expect_punct(P, ')', "期望 ')'") < 0) return -1;
        *out = call;
    }
    return 0;
}

static int parse_unary(parser_t *P, expr_t **out) {
    p_peek(P);
    if (is_op(P, "-") || is_op(P, "!") || is_op(P, "~") ||
        is_op(P, "*") || is_op(P, "&") ||
        is_op(P, "++") || is_op(P, "--")) {
        expr_t *e = new_expr(EX_UNARY);
        e->line = P->cur.line; e->col = P->cur.col;
        e->op_text = P->cur.start; e->op_len = P->cur.len;
        p_advance(P);
        if (parse_unary(P, &e->operand) < 0) return -1;
        *out = e; return 0;
    }
    return parse_postfix(P, out);
}

static int parse_pow(parser_t *P, expr_t **out) {
    if (parse_unary(P, out) < 0) return -1;
    p_peek(P);
    while (is_op(P, "**")) {
        expr_t *e = new_expr(EX_BINARY);
        e->line = P->cur.line; e->col = P->cur.col;
        e->op_text = P->cur.start; e->op_len = P->cur.len;
        p_advance(P);
        e->left = *out;
        if (parse_unary(P, &e->right) < 0) return -1;
        *out = e;
        p_peek(P);
    }
    return 0;
}

static int parse_mul(parser_t *P, expr_t **out) {
    if (parse_pow(P, out) < 0) return -1;
    p_peek(P);
    while (is_op(P, "*") || is_op(P, "/") || is_op(P, "%")) {
        expr_t *e = new_expr(EX_BINARY);
        e->line = P->cur.line; e->col = P->cur.col;
        e->op_text = P->cur.start; e->op_len = P->cur.len;
        p_advance(P);
        e->left = *out;
        if (parse_pow(P, &e->right) < 0) return -1;
        *out = e;
        p_peek(P);
    }
    return 0;
}

static int parse_add(parser_t *P, expr_t **out) {
    if (parse_mul(P, out) < 0) return -1;
    p_peek(P);
    while (is_op(P, "+") || is_op(P, "-")) {
        expr_t *e = new_expr(EX_BINARY);
        e->line = P->cur.line; e->col = P->cur.col;
        e->op_text = P->cur.start; e->op_len = P->cur.len;
        p_advance(P);
        e->left = *out;
        if (parse_mul(P, &e->right) < 0) return -1;
        *out = e;
        p_peek(P);
    }
    return 0;
}

static int parse_cmp(parser_t *P, expr_t **out) {
    if (parse_add(P, out) < 0) return -1;
    p_peek(P);
    while (is_op(P, "<") || is_op(P, ">") || is_op(P, "<=") ||
           is_op(P, ">=") || is_op(P, "==") || is_op(P, "\\=")) {
        expr_t *e = new_expr(EX_BINARY);
        e->line = P->cur.line; e->col = P->cur.col;
        e->op_text = P->cur.start; e->op_len = P->cur.len;
        p_advance(P);
        e->left = *out;
        if (parse_add(P, &e->right) < 0) return -1;
        *out = e;
        p_peek(P);
    }
    return 0;
}

static int parse_logic_and(parser_t *P, expr_t **out) {
    if (parse_cmp(P, out) < 0) return -1;
    p_peek(P);
    while (is_op(P, "&&")) {
        expr_t *e = new_expr(EX_BINARY);
        e->line = P->cur.line; e->col = P->cur.col;
        e->op_text = P->cur.start; e->op_len = P->cur.len;
        p_advance(P);
        e->left = *out;
        if (parse_cmp(P, &e->right) < 0) return -1;
        *out = e;
        p_peek(P);
    }
    return 0;
}

static int parse_logic_or(parser_t *P, expr_t **out) {
    if (parse_logic_and(P, out) < 0) return -1;
    p_peek(P);
    while (is_op(P, "||")) {
        expr_t *e = new_expr(EX_BINARY);
        e->line = P->cur.line; e->col = P->cur.col;
        e->op_text = P->cur.start; e->op_len = P->cur.len;
        p_advance(P);
        e->left = *out;
        if (parse_logic_and(P, &e->right) < 0) return -1;
        *out = e;
        p_peek(P);
    }
    return 0;
}

static int parse_assign(parser_t *P, expr_t **out) {
    if (parse_logic_or(P, out) < 0) return -1;
    p_peek(P);
    if (is_op(P, "=") || is_op(P, "+=") || is_op(P, "-=") ||
        is_op(P, "*=") || is_op(P, "/=") || is_op(P, "%=")) {
        expr_t *e = new_expr(EX_ASSIGN);
        e->line = P->cur.line; e->col = P->cur.col;
        e->op_text = P->cur.start; e->op_len = P->cur.len;
        p_advance(P);
        e->left = *out;
        if (parse_assign(P, &e->right) < 0) return -1;
        *out = e;
    }
    return 0;
}

static int parse_expr(parser_t *P, expr_t **out) {
    return parse_assign(P, out);
}

/* ============ 语句 ============ */

/* 变量名 为 类型 值; */
static int parse_let(parser_t *P, stmt_t **out) {
    stmt_t *s = new_stmt(ST_LET);
    s->line = P->cur.line; s->col = P->cur.col;

    /* 名 */
    if (P->cur.kind != TOK_IDENT) return p_err(P, "期望变量名");
    s->name = P->cur.start;
    s->name_len = P->cur.len;
    p_advance(P);

    /* 为 / is */
    if (!is_kw(P, KW_IS)) return p_err(P, "期望 '为' 或 'is'");
    p_advance(P);

    /* 类型 */
    if (parse_type(P, &s->type) < 0) return -1;

    /* 值（可选） */
    p_peek(P);
    if (!is_punct(P, ';')) {
        if (parse_expr(P, &s->init) < 0) return -1;
    }

    if (expect_punct(P, ';', "期望 ';'") < 0) return -1;
    *out = s; return 0;
}

static int parse_return(parser_t *P, stmt_t **out) {
    stmt_t *s = new_stmt(ST_RETURN);
    s->line = P->cur.line; s->col = P->cur.col;
    p_advance(P);
    p_peek(P);
    if (!is_punct(P, ';')) {
        if (parse_expr(P, &s->expr) < 0) return -1;
    }
    if (expect_punct(P, ';', "期望 ';'") < 0) return -1;
    *out = s; return 0;
}

static int parse_if(parser_t *P, stmt_t **out) {
    stmt_t *s = new_stmt(ST_IF);
    s->line = P->cur.line; s->col = P->cur.col;
    p_advance(P);
    if (parse_expr(P, &s->cond) < 0) return -1;
    if (parse_block(P, &s->then_s) < 0) return -1;
    p_peek(P);
    if (is_kw(P, KW_ELSE)) {
        p_advance(P);
        p_peek(P);
        if (is_kw(P, KW_IF)) {
            if (parse_if(P, &s->else_s) < 0) return -1;
        } else {
            if (parse_block(P, &s->else_s) < 0) return -1;
        }
    }
    *out = s; return 0;
}

static int parse_while(parser_t *P, stmt_t **out) {
    stmt_t *s = new_stmt(ST_WHILE);
    s->line = P->cur.line; s->col = P->cur.col;
    p_advance(P);
    if (parse_expr(P, &s->cond) < 0) return -1;
    if (parse_block(P, &s->body) < 0) return -1;
    *out = s; return 0;
}

static int parse_for(parser_t *P, stmt_t **out) {
    stmt_t *s = new_stmt(ST_FOR);
    s->line = P->cur.line; s->col = P->cur.col;
    p_advance(P);

    /* init: 声明或空 */
    p_peek(P);
    if (is_punct(P, ';')) {
        p_advance(P);
    } else if (P->cur.kind == TOK_IDENT) {
        if (parse_let(P, &s->for_init) < 0) return -1;
    } else {
        p_err(P, "期望 for 初始化");
        return -1;
    }

    /* cond */
    p_peek(P);
    if (!is_punct(P, ';')) {
        if (parse_expr(P, &s->for_cond) < 0) return -1;
    }
    if (expect_punct(P, ';', "期望 ';'") < 0) return -1;

    /* step */
    p_peek(P);
    if (!is_punct(P, '{')) {
        if (parse_expr(P, &s->for_step) < 0) return -1;
    }

    if (parse_block(P, &s->body) < 0) return -1;
    *out = s; return 0;
}

static int parse_expr_stmt(parser_t *P, stmt_t **out) {
    stmt_t *s = new_stmt(ST_EXPR);
    s->line = P->cur.line; s->col = P->cur.col;
    if (parse_expr(P, &s->expr) < 0) return -1;
    if (expect_punct(P, ';', "期望 ';'") < 0) return -1;
    *out = s; return 0;
}

static int parse_stmt(parser_t *P, stmt_t **out) {
    p_peek(P);

    if (is_kw(P, KW_RETURN))                       return parse_return(P, out);
    if (is_kw(P, KW_IF))                           return parse_if(P, out);
    if (is_kw(P, KW_WHILE))                        return parse_while(P, out);
    if (is_kw(P, KW_FOR))                          return parse_for(P, out);

    /* 声明：IDENT 后面跟 '为' / 'is' */
    if (P->cur.kind == TOK_IDENT) {
    token_t save_cur = P->cur;
    p_peek(P);
    int next_is_is = (P->next.kind == TOK_KEYWORD &&
                      P->next.kw_id == KW_IS);
    P->cur = save_cur;
    if (next_is_is) {
        return parse_let(P, out);
    }
    /* 不是声明，继续按表达式 */
    }

    if (is_punct(P, '{')) return parse_block(P, out);
    if (is_punct(P, ';')) {
        p_advance(P);
        *out = NULL;
        return 0;
    }

    return parse_expr_stmt(P, out);
}

static int parse_block(parser_t *P, stmt_t **out) {
    if (expect_punct(P, '{', "期望 '{'") < 0) return -1;
    stmt_t *blk = new_stmt(ST_BLOCK);
    for (;;) {
        p_peek(P);
        if (is_punct(P, '}')) break;
        if (P->cur.kind == TOK_EOF) return p_err(P, "未闭合的 '{'");
        stmt_t *s = NULL;
        if (parse_stmt(P, &s) < 0) return -1;
        if (s) add_stmt(blk, s);
    }
    p_advance(P);
    *out = blk;
    return 0;
}

/* 函 名 (a: 类型, ...) -> 类型 { } */
static int parse_func(parser_t *P, func_t **out) {
    func_t *f = calloc(1, sizeof(*f));
    if (!f) { fprintf(stderr, "out of memory\n"); exit(1); }

    if (P->cur.kind != TOK_IDENT) return p_err(P, "期望函数名");
    f->name = P->cur.start;
    f->name_len = P->cur.len;
    p_advance(P);

    if (expect_punct(P, '(', "期望 '('") < 0) return -1;

    if (!is_punct(P, ')')) {
        for (;;) {
            p_peek(P);
            if (P->cur.kind != TOK_IDENT) return p_err(P, "期望参数名");
            const char *nm = P->cur.start;
            int nml = P->cur.len;
            p_advance(P);

            if (expect_op(P, ":", "期望 ':'") < 0) return -1;

            type_desc_t ty;
            if (parse_type(P, &ty) < 0) return -1;

            f->params = realloc(f->params, sizeof(param_t) * (f->nparams + 1));
            f->params[f->nparams].name = nm;
            f->params[f->nparams].name_len = nml;
            f->params[f->nparams].type = ty;
            f->nparams++;

            p_peek(P);
            if (is_punct(P, ',')) { p_advance(P); continue; }
            break;
        }
    }
    if (expect_punct(P, ')', "期望 ')'") < 0) return -1;

    p_peek(P);
    if (is_op(P, "->")) {
        p_advance(P);
        if (parse_type(P, &f->ret_type) < 0) return -1;
        f->has_ret = 1;
    }

    if (parse_block(P, &f->body) < 0) return -1;
    *out = f;
    return 0;
}

int parse_program(lexer_t *L, program_t *out) {
    parser_t P;
    memset(&P, 0, sizeof(P));
    P.L = L;
    if (lex_next(L, &P.cur) < 0) return -1;

    for (;;) {
        p_peek(&P);
        if (P.cur.kind == TOK_EOF) break;

        if (P.cur.kind == TOK_PREPROC) {
            out->includes = realloc(out->includes,
                                    sizeof(include_t) * (out->nincludes + 1));
            out->includes[out->nincludes].text = P.cur.start;
            out->includes[out->nincludes].len  = P.cur.len;
            out->nincludes++;
            p_advance(&P);
            continue;
        }

        if (is_kw(&P, KW_FN)) {
            p_advance(&P);
            func_t *f = NULL;
            if (parse_func(&P, &f) < 0) return -1;
            out->funcs = realloc(out->funcs, sizeof(func_t*) * (out->nfuncs + 1));
            out->funcs[out->nfuncs++] = f;
            continue;
        }

        return p_err(&P, "期望函数定义或预编译指令");
    }
    return 0;
}